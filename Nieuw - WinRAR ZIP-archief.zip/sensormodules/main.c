#define F_CPU 2000000UL
#include <avr/io.h>
#include <util/delay.h>
#include "nrf24spiXM2.h"
#include "nrf24L01.h"

uint8_t  pipe[5] = {0x48, 0x76, 0x41, 0x30, 0x31};       // pipe address "HvA01"

void     init_nrf(void);
void     init_adc(void);
int16_t  read_adc(void);

int main(void)
{
	int16_t result;

	init_adc();
	init_nrf();

	while (1) {
		result = read_adc();
		nrfWrite( (uint8_t *) &result, sizeof(uint16_t) );  // little endian: low byte is sent first
		_delay_ms(20);
	}
}



void init_nrf(void)
{
	nrfspiInit();                                        // Initialize SPI
	nrfBegin();                                          // Initialize radio module

	nrfSetRetries(NRF_SETUP_ARD_1000US_gc,               // Auto Retransmission Delay: 1000 us
	NRF_SETUP_ARC_8RETRANSMIT_gc);         // Auto Retransmission Count: 8 retries
	nrfSetPALevel(NRF_RF_SETUP_PWR_6DBM_gc);             // Power Control: -6 dBm
	nrfSetDataRate(NRF_RF_SETUP_RF_DR_250K_gc);          // Data Rate: 250 Kbps
	nrfSetCRCLength(NRF_CONFIG_CRC_16_gc);               // CRC Check
	nrfSetChannel(54);                                   // Channel: 54
	nrfSetAutoAck(1);                                    // Auto Acknowledge on
	nrfEnableDynamicPayloads();                          // Enable Dynamic Payloads

	nrfClearInterruptBits();                             // Clear interrupt bits
	nrfFlushRx();                                        // Flush fifo's
	nrfFlushTx();

	nrfOpenWritingPipe(pipe);                            // Pipe for sending
	nrfOpenReadingPipe(0, pipe);                         // Necessary for acknowledge
}

void init_adc(void)
{
	PORTA.DIRCLR     = PIN0_bm;                              //
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN0_gc |               // PA0 to + channel 0
	ADC_CH_MUXNEG_GND_MODE3_gc;           // GND to - channel 0
	ADCA.CH0.CTRL    = ADC_CH_INPUTMODE_DIFF_gc;             // channel 0 differential
	ADCA.REFCTRL     = ADC_REFSEL_INTVCC_gc;
	ADCA.CTRLB       = ADC_RESOLUTION_12BIT_gc |
	ADC_CONMODE_bm;                       // signed conversion
	ADCA.PRESCALER   = ADC_PRESCALER_DIV16_gc;
	ADCA.CTRLA       = ADC_ENABLE_bm;
}

int16_t read_adc(void)                                     // return a signed
{
	int16_t res;                                             // is also signed

	ADCA.CH0.CTRL |= ADC_CH_START_bm;
	while ( !(ADCA.CH0.INTFLAGS & ADC_CH_CHIF_bm) ) ;
	res = ADCA.CH0.RES;
	ADCA.CH0.INTFLAGS |= ADC_CH_CHIF_bm;

	return res;
}